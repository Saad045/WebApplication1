﻿using WebApplication1.Modal;
namespace WebApplication1
{
    Book obj = new Book();
    public class WriteINtoJson
    {

        int id;
        string name;
        string image;

        public void createStudent()
        {
            
            id = 10;
            name = "NewBook";
            image = "google.com";

            StreamWriter file = new StreamWriter("E:\\C#\\WebApplication1\\WebApplication1\\wwwroot\\data\\books.json", append: true);
            file.WriteLine(obj.ToString());
            file.Flush();
            file.Close();

        }
    }
}
